
import csv
with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        if float(linha['Population (Est.)']) > 20000:
            print(linha)



    if float(linha['Population (Est.)']) > 10000 and int(linha['Area (sq km)']) < 5000:
        print(linha)