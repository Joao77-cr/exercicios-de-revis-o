'''
import csv



#importamos o dadabase em questão e calculmaos a quantidade de registros e colocamos dentro do dicionario usando Dictreader
with open ('world_largest_cities.csv','r',encoding='utf-8') as arquivo :
    leitor=csv.DictReader(arquivo)
    for registro in leitor:
        print(registro['Population (Est.)'],registro['Area (sq km)'])
   
    contador=0
    for linha in leitor:
        if contador < 5:
            print(linha)  # head
        
        contador += 1

print("Total de registros:", contador)


'''







#printamos o nome do data base
print("world_largest_cities.csv")
        
    