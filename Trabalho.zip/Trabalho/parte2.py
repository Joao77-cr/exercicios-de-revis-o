'''
import csv
#achar o mneor valor usando "for"
menor = float('inf')
linha_menor = None
with open ('world_largest_cities.csv','r',encoding='utf-8') as arquivo :
    leitor=csv.DictReader(arquivo)
    for registro in leitor:
         print(registro['Population (Est.)'],registro['Area (sq km)'])


    for linha in leitor:
        valor = float(linha['Population (Est.)'])  # nome da coluna
        
        if valor < menor:
            menor = valor
maior = float('-inf')

with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        valor = float(linha['Population (Est.)'])
        
        if valor > maior:
            maior = valor

print("Maior valor:", maior)



#para calcular "media"
soma = 0
contador = 0


with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        valor = float(linha['Population (Est.)'])
        soma += valor
        contador += 1

media = soma / contador

print("Média:", media)
print("Menor valor:", menor)

valid = 0

with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        if linha['Population (Est.)'] != '':
            valid += 1

print("Registros válidos:", valid)
'''
'''
for linha in leitor:
        valor = float(linha['Area (sq km)'])  # nome da coluna
        
        if valor < menor:
            menor = valor
maior = float('-inf')

with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        valor = float(linha['Area (sq km)'])
        
        if valor > maior:
            maior = valor

print("Maior valor:", maior)



#para calcular "media"
soma = 0
contador = 0


with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        valor = float(linha['Area (sq km)'])
        soma += valor
        contador += 1

media = soma / contador

print("Média:", media)
print("Menor valor:", menor)

valid = 0

with open('world_largest_cities.csv', 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    
    for linha in leitor:
        if linha['Area (sq km)'] != '':
            valid += 1

print("Registros válidos:", valid)
'''